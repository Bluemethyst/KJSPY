from .src.kjspy import (
    FluidRegistry,
    ItemRegistry,
    BlockRegistry,
    Recipes,
    init,
)